# MVP-SCOPE — Contrato de Safra

## O que ESTÁ no MVP

### Must Have
- Cadastro/login do vendedor (Supabase Auth)
- Formulário guiado por abas para criação do contrato (comprador, cultura, unidade/quantidade, valor, pagamento/prazo)
- Lista pré-configurada de culturas comuns da região (cebola, tomate, beterraba, cenoura + opção "outra" descritiva)
- Geração de link único de confirmação para o comprador (sem cadastro)
- Tela de confirmação do comprador (confirmar ou sinalizar divergência)
- Geração de PDF final do contrato, com código de verificação e timestamp
- Histórico de contratos do vendedor com status

### Should Have (entra no MVP se o tempo permitir)
- Reenvio de link expirado
- Edição de contrato em rascunho antes do envio

## O que NÃO está no MVP (Future Scope)

- Cadastro/conta para o comprador
- Marketplace / rede de conexão entre compradores e vendedores que ainda não se falaram
- CPR (Cédula de Produtor Rural) formal, com força de título de crédito executável
- Assinatura digital integrada (ICP-Brasil via gov.br API, ou DocuSign/Clicksign)
- Cobrança de % sobre o valor do contrato (monetização)
- Notificações automáticas via WhatsApp (envio do link continua manual pelo vendedor, por enquanto)
- Multi-idioma, multi-moeda (fora de escopo, produto é local/BRL)

## Justificativa das Decisões de Escopo

- **Sem cadastro do comprador**: reduz drasticamente a complexidade técnica (sem fluxo de autenticação duplo) e a fricção de uso — o comprador só precisa revisar e confirmar, não "criar uma conta pra assinar um contrato que ele nem sabe se vai fechar".
- **Sem monetização inicial**: o objetivo do MVP é validar se o produto resolve a dor. Cobrar cedo demais pode matar a adoção antes de provar valor.
- **Sem marketplace**: conectar desconhecidos é um produto completamente diferente (com problemas de confiança, reputação, moderação). Resolver primeiro a dor de quem **já negociou** e só precisa formalizar é o caminho de menor risco.
- **Sem CPR formal**: exige requisitos legais mais rígidos (registro em cartório de RTD ou CRA, dependendo do modelo). Começar pelo contrato particular simples é mais rápido de validar e já resolve o problema relatado (falta de qualquer registro).
- **Assinatura fora do app**: elimina a necessidade de integração com certificado digital ou gateway de assinatura eletrônica no MVP — reduz custo e tempo de desenvolvimento sem comprometer a validade jurídica do documento entre as partes.

## Hipóteses a Validar

1. O vendedor prefere preencher um formulário guiado no app a negociar só por áudio de WhatsApp (parece óbvio, mas precisa ser observado no uso real).
2. O PDF gerado pelo app é aceito sem resistência pelo comprador, mesmo vindo de uma ferramenta nova e desconhecida na região.
3. As categorias de cultura pré-definidas cobrem a maioria dos casos reais de negociação sem exigir descrição livre na maior parte das vezes.
4. A ausência de cadastro do comprador não gera desconfiança ("como assim ele não precisa se identificar no sistema?").

## Métricas de Sucesso do MVP

- Nº de contratos criados
- Nº de contratos confirmados pelo comprador (taxa de confirmação)
- Nº de vendedores que geraram mais de um contrato (sinal de retenção/recorrência)
- Feedback qualitativo direto dos primeiros usuários (Romulo e rede dele) sobre fricção e confiança no processo
