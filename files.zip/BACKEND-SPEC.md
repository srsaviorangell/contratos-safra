# BACKEND-SPEC — Contrato de Safra

## Princípio Geral
Arquitetura **client-side first**: a maior parte das operações (leitura de contratos, formulário, listagem) acontece direto do client para o Supabase, usando RLS como camada de segurança — não como "extra". Server-side (Route Handlers / Server Actions do Next.js) é usado apenas onde é **estritamente necessário**:

1. Validação e acesso via `confirmation_token` (comprador nunca tem sessão autenticada)
2. Geração de PDF
3. Cálculo/geração de `verification_hash`
4. Expiração automática de tokens (job/cron)

## Supabase — Configuração

### Auth
- Apenas vendedores possuem conta (`auth.users` + tabela `profiles`)
- Método: e-mail/senha no MVP (avaliar OTP por SMS como melhoria, dado o público rural que pode ter menos familiaridade com senhas)

### RLS (Row Level Security)
- `profiles`: usuário só acessa `id = auth.uid()`
- `contracts`: usuário só acessa linhas onde `seller_id = auth.uid()`
- `crop_types`: leitura pública para qualquer usuário autenticado, escrita bloqueada para clients (gerenciado via migration)
- Acesso do **comprador** aos dados do contrato NUNCA passa pela política de usuário autenticado — é feito por uma rota server-side com `service_role` restrita, que:
  1. Recebe o token da URL
  2. Verifica se existe um contrato com aquele `confirmation_token`
  3. Verifica se `confirmation_expires_at` ainda é válido e status é `aguardando_confirmacao`
  4. Se válido, retorna os dados formatados (nunca o registro bruto da tabela)
  5. Se inválido/expirado, retorna estado apropriado (expirado, não encontrado)

## Rotas Server-Side (Route Handlers / Server Actions)

### `POST /api/contracts` (ou Server Action equivalente)
- Cria contrato em status `rascunho`
- Validação server-side dos campos obrigatórios (mesmo que o client já valide, nunca confiar só no client)

### `POST /api/contracts/[id]/send`
- Transição `rascunho` → `aguardando_confirmacao`
- Gera `confirmation_token` (uuid) e `confirmation_expires_at` (now + 7 dias)
- Invalida qualquer token anterior daquele contrato, se houver

### `GET /api/confirmar/[token]`
- Rota pública, usada pela página `/confirmar/[token]`
- Retorna dados do contrato se o token for válido e não expirado
- Não expõe `seller_id`, `verification_hash` nem qualquer dado interno desnecessário

### `POST /api/confirmar/[token]/confirmar`
- Muda status para `confirmado`
- Grava `confirmed_at`
- Gera `verification_hash` (hash dos dados do contrato + timestamp)
- Dispara geração do PDF (síncrona ou enfileirada, mas resposta ao usuário deve ser rápida — considerar gerar o PDF de forma assíncrona e notificar quando pronto, se a geração demorar)
- Salva PDF no bucket `contracts-pdf` do Supabase Storage
- Atualiza `pdf_url` no contrato

### `POST /api/confirmar/[token]/divergencia`
- Muda status para `divergencia`
- Grava `divergence_note` com o texto informado pelo comprador
- Token é invalidado (não pode ser usado novamente para confirmar)

### `POST /api/contracts/[id]/nova-versao`
- Usado quando contrato está em `divergencia`
- Cria novo registro em `contracts` com `parent_contract_id` apontando para o original
- Novo contrato nasce em status `rascunho`, pré-preenchido com os dados do original para o vendedor ajustar

### Job de Expiração (cron/scheduled function)
- Roda periodicamente (ex: 1x por dia)
- Busca contratos em `aguardando_confirmacao` com `confirmation_expires_at` no passado
- Atualiza status para `expirado`

## Geração de PDF
- Biblioteca sugerida: `@react-pdf/renderer` (permite compor o PDF com componentes React, mantendo consistência visual com o design system) ou `pdf-lib` para maior controle de baixo nível
- Conteúdo obrigatório no PDF:
  - Todos os dados do contrato (partes, cultura, quantidade, unidade, valor unitário e total, forma de pagamento, prazo, data de entrega)
  - Código de verificação (`verification_hash`) e timestamp de confirmação
  - Texto padrão informando que a assinatura (física com testemunhas ou digital via gov.br) é de responsabilidade das partes, fora do app
- PDF gerado apenas no momento da confirmação — nunca antes disso (ver BUSINESS-RULES.md, regra 7)

## Segurança
- Nenhuma chave `service_role` do Supabase deve ser exposta no client — usada apenas nas rotas server-side descritas acima
- Rate limiting básico na rota `/api/confirmar/[token]` para evitar tentativas de força bruta contra tokens (mesmo sendo UUIDs, é boa prática)
- Nunca logar o conteúdo completo do contrato (dados de negociação) em logs de aplicação
