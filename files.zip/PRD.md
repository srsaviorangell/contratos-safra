# PRD — Contrato de Safra

## 1. Visão Geral do Produto
Ferramenta web (mobile-first, mas acessível via navegador) que permite ao vendedor rural gerar um contrato de compra e venda de safra personalizado por negociação, e ao comprador confirmar os termos via link, sem necessidade de cadastro. O documento final é um PDF pronto para assinatura externa (gov.br ou cartório).

Stack fixa: **Next.js + Supabase**, arquitetura client-side first (mínimo de server-side), UI com **shadcn/ui**, estilo clean/moderno/light mode (referências: Linear, Resend, Vercel).

## 2. Personas

### Persona 1 — Vendedor (Produtor Rural)
- Tem uma conta no app
- Vende safras diversas (cebola, tomate, beterraba, cenoura, entre outras)
- Hoje fecha negócio só verbalmente ou por áudio de WhatsApp
- Não tem paciência para jargão jurídico nem processos longos
- Quer confiança de que "ficou documentado"

### Persona 2 — Comprador
- Não tem cadastro no app
- Recebe um link (provavelmente via WhatsApp) com os dados do contrato
- Precisa apenas revisar e confirmar (ou sinalizar divergência) rapidamente, pelo celular

## 3. User Stories

- Como **vendedor**, quero selecionar a cultura vendida a partir de uma lista pré-configurada, para não precisar descrever tudo do zero.
- Como **vendedor**, quero definir a unidade de medida (saco, caixa, pé, kg, tonelada) específica daquela cultura, para que o contrato reflita como o negócio realmente é fechado na região.
- Como **vendedor**, quero informar quantidade, valor por unidade, forma de pagamento e prazo, para que o contrato tenha todos os termos combinados.
- Como **vendedor**, quero gerar um link único para o comprador confirmar os dados, para evitar divergência sobre o que foi acordado.
- Como **vendedor**, quero ver o histórico de todos os contratos que já gerei, para ter controle das minhas negociações.
- Como **comprador**, quero abrir o link recebido sem precisar criar conta, para confirmar rapidamente os termos do negócio.
- Como **comprador**, quero poder sinalizar que um dado está errado antes de confirmar, para evitar assinar algo que não foi o combinado.
- Como **vendedor**, quero baixar o PDF final do contrato após a confirmação do comprador, para levar à assinatura (gov.br ou cartório).

## 4. Requisitos Funcionais

### 4.1 Autenticação (Vendedor)
- Cadastro e login via Supabase Auth (e-mail/senha; avaliar login por telefone/OTP como alternativa dado o público-alvo rural)
- Comprador **não** possui conta — acesso via token único na URL

### 4.2 Criação de Contrato (formulário por abas)
- Aba 1: Dados do comprador (nome, documento opcional, contato)
- Aba 2: Cultura (lista pré-configurada + opção "outra", campo descritivo livre)
- Aba 3: Unidade de medida e quantidade (dependente da cultura selecionada, mas sempre editável)
- Aba 4: Valor (por unidade e total calculado automaticamente)
- Aba 5: Forma de pagamento e prazo (à vista, parcelado, data de entrega)
- Revisão final antes de gerar o link

### 4.3 Confirmação do Comprador
- Link único com token, sem necessidade de login
- Tela de revisão dos dados em linguagem simples
- Botão "Confirmar" ou "Isso está errado" (com campo de observação livre)
- Ao confirmar, contrato muda de status e libera geração do PDF final

### 4.4 Geração de PDF
- PDF gerado a partir dos dados estruturados do contrato
- Inclui código de verificação/hash simples e timestamp de geração (prova de integridade — não é assinatura digital)
- Texto claro informando que a assinatura (física ou via gov.br) deve ser feita fora do app

### 4.5 Histórico
- Lista de contratos do vendedor com status (rascunho, aguardando confirmação, confirmado, expirado)
- Reenvio de link se necessário

## 5. Requisitos Não-Funcionais
- Geração de PDF em poucos segundos
- Acesso do comprador funcional em conexão de internet fraca (comum em zona rural) — priorizar leveza da página de confirmação
- Interface responsiva, mobile-first
- Token de confirmação com expiração configurável (padrão: 7 dias)
- Dados sensíveis (valores de contrato) protegidos por RLS (Row Level Security) no Supabase

## 6. Integrações Necessárias
- Supabase Auth (cadastro/login do vendedor)
- Supabase Database (Postgres) para contratos, culturas, e tokens de confirmação
- Supabase Storage (armazenamento dos PDFs gerados)
- Geração de PDF: biblioteca client-side (ex: `@react-pdf/renderer` ou `pdf-lib`) rodando via Server Action/Route Handler do Next.js, mantendo o mínimo de lógica server-side possível

## 7. Casos de Borda
- Comprador não confirma dentro do prazo do token → contrato marcado como "expirado", vendedor pode reenviar novo link
- Vendedor edita contrato após envio do link, mas antes da confirmação → token antigo invalidado, novo link deve ser gerado
- Comprador sinaliza divergência → contrato volta para edição do vendedor, sem invalidar o cadastro do comprador já informado
- Unidade de medida incompatível com a cultura (ex: selecionar "pé" para cebola, que normalmente é vendida por saco/kg) → sistema alerta mas não bloqueia (produtor conhece melhor a realidade local que qualquer lista pré-definida)
- Vendedor tenta gerar contrato sem valor definido → bloqueado, valor é campo obrigatório (necessário mesmo sem cobrança de %, pois faz parte do conteúdo do contrato)

## 8. Critérios de Aceitação (exemplos)
- **Criação de contrato**: vendedor consegue concluir as 5 abas e gerar link em menos de 3 minutos, sem precisar preencher campos fora da ordem
- **Confirmação**: comprador consegue confirmar em uma única tela, sem scroll excessivo, em conexão 3G
- **PDF**: documento gerado contém todos os campos preenchidos, código de verificação, e aviso claro de que a assinatura é externa
- **Histórico**: vendedor visualiza status atualizado de todos os contratos sem precisar recarregar manualmente
