# DATABASE-SCHEMA — Contrato de Safra (Supabase / Postgres)

## Visão Geral
- Banco: Postgres via Supabase
- Autenticação: `auth.users` nativo do Supabase (apenas para vendedores)
- RLS (Row Level Security) habilitado em todas as tabelas que contêm dados de vendedor
- Comprador nunca acessa o banco diretamente com credenciais — todo acesso dele passa por uma rota/Server Action que valida o token de confirmação

---

## Tabelas

### `profiles`
Extensão dos dados do vendedor (complementa `auth.users`).

| Coluna       | Tipo        | Regras |
|--------------|-------------|--------|
| id           | uuid (PK)   | referencia `auth.users.id` |
| full_name    | text        | obrigatório |
| phone        | text        | obrigatório (contato principal, já que público-alvo usa WhatsApp) |
| region       | text        | opcional, cidade/região do produtor |
| created_at   | timestamptz | default now() |

RLS: usuário só lê/edita seu próprio registro (`id = auth.uid()`).

---

### `crop_types`
Tabela de seed, culturas pré-configuradas.

| Coluna           | Tipo      | Regras |
|------------------|-----------|--------|
| id               | uuid (PK) |  |
| name             | text      | ex: "Cebola", "Tomate", "Beterraba", "Cenoura" |
| default_unit     | text      | ex: "saco", "caixa", "kg" — apenas sugestão default |
| description      | text      | opcional, ex: "Caixa classificada em 1ª, 2ª ou 3ª qualidade" |
| is_active        | boolean   | default true |

RLS: leitura pública (todo vendedor autenticado pode ler), sem escrita via client (seed gerenciado via migration/admin).

---

### `contracts`
Tabela central do sistema.

| Coluna                  | Tipo        | Regras |
|-------------------------|-------------|--------|
| id                      | uuid (PK)   |  |
| seller_id               | uuid (FK)   | referencia `profiles.id`, obrigatório |
| crop_type_id            | uuid (FK)   | referencia `crop_types.id`, nullable se `crop_type_custom` preenchido |
| crop_type_custom        | text        | usado quando vendedor escolhe "outra cultura" |
| unit_type               | text        | obrigatório (ex: "saco", "caixa", "pé", "kg", "tonelada") |
| quantity                | numeric     | obrigatório, > 0 |
| unit_price              | numeric     | obrigatório, > 0, em BRL |
| total_value             | numeric     | calculado (quantity × unit_price), nunca editado manualmente |
| payment_method          | text        | ex: "à vista", "parcelado", "cheque" — campo descritivo |
| payment_term            | text        | descritivo, ex: "30 dias após entrega" |
| delivery_date           | date        | opcional |
| buyer_name              | text        | obrigatório |
| buyer_document          | text        | opcional (CPF/CNPJ) |
| buyer_contact           | text        | opcional (telefone) |
| status                  | text        | enum: `rascunho`, `aguardando_confirmacao`, `confirmado`, `divergencia`, `expirado` |
| confirmation_token      | uuid        | gerado ao sair de `rascunho`, único, não reutilizável |
| confirmation_expires_at | timestamptz | token válido por 7 dias a partir da geração |
| confirmed_at            | timestamptz | preenchido quando comprador confirma |
| divergence_note         | text        | preenchido se comprador sinalizar divergência |
| parent_contract_id      | uuid (FK)   | nullable — referencia o contrato original, se este for uma nova versão gerada após divergência |
| verification_hash       | text        | gerado no momento da confirmação, usado no PDF |
| pdf_url                 | text        | link do arquivo no Supabase Storage, preenchido após confirmação |
| created_at              | timestamptz | default now() |
| updated_at               | timestamptz | atualizado a cada mudança de status |

RLS:
- Vendedor só lê/edita contratos onde `seller_id = auth.uid()`.
- Acesso do comprador **não passa por RLS de usuário autenticado** — é feito via rota server-side que valida `confirmation_token` e `confirmation_expires_at` antes de expor os dados (comprador nunca tem uma sessão Supabase).

---

## Relacionamentos

```
profiles (1) ──── (N) contracts
crop_types (1) ──── (N) contracts
contracts (1) ──── (0..1) contracts   [parent_contract_id, versionamento por divergência]
```

## Índices Recomendados
- `contracts.seller_id` — listagem de histórico por vendedor
- `contracts.confirmation_token` — busca rápida na tela de confirmação do comprador (índice único)
- `contracts.status` — filtros no histórico

## Storage (Supabase Storage)
- Bucket `contracts-pdf`, privado
- Caminho sugerido: `{seller_id}/{contract_id}.pdf`
- Acesso ao PDF via signed URL de curta duração, gerada sob demanda (não expor bucket público)
