# AGENT-CONTEXT — Guia Mestre para o Agente de IA

Este documento existe para que qualquer agente de IA (Claude Code, Cursor, etc.) que for implementar este projeto **não se perca, não invente escopo, e não tome decisões técnicas contrárias ao que já foi definido**. Leia este arquivo antes de qualquer outro. Em caso de conflito entre o que parece "melhor tecnicamente" e o que está documentado aqui, **este documento e os demais arquivos do projeto têm prioridade sobre suposições do agente**.

## O Produto, em uma frase
App onde o vendedor de safra monta um contrato de compra e venda guiado por abas, o comprador confirma via link (sem cadastro), e o sistema gera um PDF pronto para assinatura fora do app.

## Stack Obrigatória (não trocar, não sugerir alternativa)
- **Next.js** (App Router) + **Supabase** (Auth, Database Postgres, Storage)
- **shadcn/ui** como base de componentes, **Tailwind CSS**
- Arquitetura **client-side first** — server-side só onde estritamente necessário (ver BACKEND-SPEC.md)
- Estilo visual: clean, moderno, **light mode** (referências: Linear, Resend, Vercel) — ver DESIGN-GUIDELINES.md

## Ordem de Leitura dos Documentos
1. `BRIEF.md` — o quê e por quê
2. `MVP-SCOPE.md` — o que entra e o que NÃO entra
3. `BUSINESS-RULES.md` — regras que não podem ser quebradas
4. `PRD.md` — requisitos detalhados
5. `DATABASE-SCHEMA.md` — schema exato do banco
6. `FRONTEND-SPEC.md` — estrutura de telas e componentes
7. `BACKEND-SPEC.md` — rotas, lógica server-side, segurança
8. `DESIGN-GUIDELINES.md` — cores, tipografia, espaçamento
9. `LANDING-PAGE-SPEC.md` — apenas se for construir a landing page

## Regras Inegociáveis (resumo — detalhes em BUSINESS-RULES.md)

1. **Comprador nunca tem cadastro.** Se em algum momento parecer "mais fácil" dar login ao comprador, **não faça isso** — é uma decisão de produto deliberada, não uma lacuna a preencher.
2. **Contrato confirmado ou aguardando confirmação não pode ser editado diretamente.** Mudanças após esse ponto exigem nova versão (`parent_contract_id`), nunca sobrescrever dados já enviados ao comprador.
3. **PDF só é gerado após confirmação do comprador**, nunca antes.
4. **Valor total é sempre calculado (quantidade × valor unitário), nunca um campo de input livre.**
5. **Nenhuma cobrança de %, checkout, ou lógica de pagamento dentro do app no MVP.** O campo de valor existe para compor o contrato, não para cobrança.
6. **Nenhuma feature de marketplace/conexão entre desconhecidos.** Isso é explicitamente fora de escopo.
7. **Nenhuma integração com assinatura digital (gov.br, Clicksign, DocuSign) ou CPR formal no MVP.** Assinatura é 100% externa ao app.
8. **Token de confirmação: 7 dias de validade, único, invalidado ao ser reenviado ou ao contrato virar nova versão.**

## O que fazer se a especificação parecer incompleta
- Se faltar um detalhe pequeno (ex: nome exato de uma variável, mensagem de erro específica), **use bom senso e siga os padrões já estabelecidos nos outros documentos** — não precisa perguntar para decisões triviais de implementação.
- Se for uma decisão de **escopo** (adicionar uma feature não listada, mudar um fluxo descrito), **não implemente por conta própria** — isso deve ser sinalizado como pergunta ao usuário/dono do produto, não resolvido silenciosamente pelo agente.

## Sinais de que o agente está se desviando do escopo (parar e reconferir os docs)
- Está criando telas de cadastro/login para o comprador
- Está adicionando campos de comissão, taxa, ou checkout
- Está desenhando um feed, busca, ou listagem pública de vendedores/compradores
- Está tentando integrar API de assinatura digital ou gerar CPR formal
- Está permitindo edição de um contrato já em `aguardando_confirmacao` ou `confirmado` sem passar pelo fluxo de nova versão

Se qualquer um desses sinais aparecer, o agente deve parar e reler `MVP-SCOPE.md` e `BUSINESS-RULES.md` antes de continuar.

## Glossário Rápido
- **Vendedor**: produtor rural, único papel com conta
- **Comprador**: quem recebe o link, sem cadastro
- **Cultura**: tipo de produto agrícola (cebola, tomate, etc.)
- **Token de confirmação**: identificador único que dá acesso do comprador ao contrato, sem login
- **Nova versão**: contrato recriado a partir de um original que teve divergência sinalizada pelo comprador
