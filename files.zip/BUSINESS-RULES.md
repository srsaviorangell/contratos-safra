# BUSINESS-RULES — Contrato de Safra

Este documento define as regras de negócio que qualquer implementação (humana ou de agente de IA) deve respeitar. Em caso de dúvida entre "o que parece mais elegante tecnicamente" e "o que está escrito aqui", **este documento prevalece**.

## 1. Papéis e Acesso

- **Vendedor**: único papel com conta no sistema (Supabase Auth). É quem cria e controla o ciclo de vida do contrato.
- **Comprador**: nunca tem conta no MVP. Acessa exclusivamente via link com token único. Todas as ações do comprador (confirmar, sinalizar divergência) acontecem sem login.
- Nenhuma tela do MVP deve exigir cadastro do comprador, sob nenhuma circunstância. Se alguma feature futura precisar disso, é sinalizada como fora de escopo, não implementada "por conveniência técnica".

## 2. Ciclo de Vida do Contrato (Status)

Um contrato deve seguir exatamente estes estados, nesta ordem, sem pular etapas:

1. **rascunho** — vendedor está preenchendo, nada foi enviado ainda. Pode editar livremente.
2. **aguardando_confirmacao** — link gerado e enviado. Contrato **bloqueado para edição** direta pelo vendedor (ver regra 3).
3. **confirmado** — comprador confirmou os dados. PDF final liberado para download.
4. **divergencia** — comprador sinalizou que algo está errado. Volta para edição do vendedor (mas gera um novo ciclo de token, ver regra 4).
5. **expirado** — token venceu sem confirmação nem divergência sinalizada.

Não existe estado "cancelado" no MVP — se o negócio não for adiante, o vendedor simplesmente não reenvia o link e o contrato expira.

## 3. Edição de Contrato

- Contrato em **rascunho**: totalmente editável.
- Contrato em **aguardando_confirmacao** ou **confirmado**: **não pode ser editado diretamente**. Se o vendedor precisar mudar algo, deve ser tratado como criação de nova versão do contrato (mantendo referência ao contrato original, para efeito de histórico), gerando um novo token.
- Isso existe para evitar que o vendedor altere valores depois que o comprador já confirmou — o que anularia o propósito do produto (registrar o que foi combinado).

## 4. Token de Confirmação

- Token único por contrato, gerado no momento do envio (transição rascunho → aguardando_confirmacao).
- Validade padrão: **7 dias** corridos a partir da geração.
- Ao expirar sem ação do comprador, status muda automaticamente para **expirado**.
- Reenvio de link por contrato expirado gera um **novo token com nova validade** — o token antigo é invalidado (nunca dois tokens válidos simultaneamente para o mesmo contrato).
- Token deve ser não sequencial e não previsível (UUID ou equivalente), já que é a única barreira de acesso do comprador — não há senha.

## 5. Cálculo de Valores

- Valor total = quantidade × valor por unidade. Calculado automaticamente, nunca digitado manualmente pelo vendedor (evita erro de conta, que foi citado como problema real nos áudios do Romulo).
- Valor por unidade e quantidade são campos obrigatórios — mesmo sem cobrança de % no MVP, o valor faz parte do conteúdo essencial do contrato (é o que dá segurança jurídica à negociação).
- Moeda fixa: BRL. Sem suporte a outras moedas no MVP.

## 6. Cultura e Unidade de Medida

- Lista de culturas pré-configurada (seed inicial: cebola, tomate, beterraba, cenoura), cada uma com uma unidade de medida sugerida como padrão (ex: cebola → saco; tomate → caixa 1ª/2ª/3ª).
- A unidade sugerida é **apenas um valor default no formulário, nunca uma trava** — o vendedor pode trocar livremente, pois o conhecimento local do produtor vale mais que qualquer lista pré-definida.
- Opção "outra cultura" sempre disponível com campo de texto livre.

## 7. Geração de PDF e Prova de Integridade

- PDF só é gerado (versão final, para download) **após** o contrato atingir o status **confirmado**.
- O PDF inclui um código de verificação (hash gerado a partir dos dados do contrato + timestamp de confirmação) — isso não é assinatura digital, é apenas uma prova de que o conteúdo não foi alterado depois da confirmação.
- O texto do PDF deve deixar explícito, em linguagem simples, que a assinatura (física com testemunhas, ou digital via gov.br) é responsabilidade das partes, fora do app.

## 8. Monetização (regra de exclusão, não de implementação)

- Nenhuma cobrança, nenhum campo de "% de comissão" deve ser implementado no MVP.
- O campo de valor do contrato já existe (regra 5) e deve ser estruturado de forma que, no futuro, sirva de base de cálculo — mas a lógica de cobrança em si **não faz parte do MVP** e não deve ser antecipada pelo agente de desenvolvimento.

## 9. Fora de Escopo (o agente de IA não deve implementar, mesmo que pareça "fácil de adicionar")

- Autenticação/cadastro do comprador
- Qualquer tela ou fluxo de marketplace (busca de compradores/vendedores)
- Integração com CPR, RTD, CRA ou qualquer registro cartorial automatizado
- Integração com gateway de assinatura digital (gov.br, Clicksign, DocuSign)
- Cobrança, checkout, ou qualquer fluxo de pagamento dentro do app
- Envio automático de WhatsApp (o compartilhamento do link continua manual, feito pelo vendedor)
