# BRIEF — Contrato de Safra

## Problema (em uma frase)
Produtores rurais fecham a venda da colheita (cebola, tomate, beterraba, cenoura, etc.) só no verbal ou por áudio de WhatsApp, sem nenhum contrato formal — o que já causou prejuízo real por falta de registro do que foi combinado (quantidade, valor, prazo, forma de pagamento).

## Solução Proposta
Um app onde o **vendedor** monta um contrato de compra e venda de safra guiado por abas (cultura, unidade de medida, quantidade, valor, forma de pagamento, prazo). O **comprador** recebe um link (sem precisar de cadastro), revisa e confirma os dados. O sistema gera um PDF final, pronto para ser assinado fora do app (gov.br ou cartório, por conta das partes).

Importante: o app **não inventa um instrumento jurídico novo**. Usa a base já existente do contrato particular de compra e venda de bem móvel, que tem validade plena entre as partes desde a assinatura, sem exigir registro em cartório (diferente de imóveis). O produto entrega **facilidade e padronização**, não um novo tipo de documento.

## Público-Alvo
Pequenos e médios produtores rurais e compradores locais de uma região específica (validação inicial entre os próprios fundadores, depois expansão para produtores da região).

## Diferencial Competitivo
- Feito para o produtor pequeno/regional — não para tradings, bancos ou grandes fintechs de agro (que já têm CPR digital, mas voltado a operações de crédito de maior porte)
- Categorias de cultura pré-configuradas com conhecimento de domínio regional (ex: cebola vendida em saco de X kg, caixa de tomate 1ª/2ª/3ª qualidade)
- Histórico de contratos do vendedor em um só lugar
- Zero fricção: sem cadastro do comprador, sem burocracia de advogado, sem custo de cartório para o contrato em si

## Modelo de Negócio
- **MVP**: gratuito, foco total em validar se o produto resolve o problema
- **Evolução futura**: cobrança de % sobre o valor do contrato gerado (ainda não implementado no MVP)

## Métricas de Sucesso
- Número de contratos gerados
- Número de vendedores ativos
- Taxa de confirmação do comprador (link enviado → confirmado)
- Feedback qualitativo dos primeiros usuários (o Romulo e a rede dele) sobre se o contrato gerado é aceito "de boa" nas negociações reais
