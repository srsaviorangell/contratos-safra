# FRONTEND-SPEC — Contrato de Safra

## Stack
- Next.js (App Router)
- shadcn/ui como base de componentes
- Tailwind CSS
- Client-side first: a maior parte da lógica de formulário, cálculo e navegação entre abas roda no client; server só é usado onde é estritamente necessário (auth, geração de PDF, validação de token)

## Estrutura de Pastas (sugestão)

```
/app
  /(auth)
    /login/page.tsx
    /cadastro/page.tsx
  /(dashboard)
    /contratos/page.tsx              -> histórico do vendedor
    /contratos/novo/page.tsx         -> formulário por abas (criação)
    /contratos/[id]/page.tsx         -> detalhe/status do contrato
  /confirmar/[token]/page.tsx        -> tela pública do comprador (sem login)
  /layout.tsx
/components
  /ui                                -> componentes shadcn/ui
  /contract-form
    tabs-cultura.tsx
    tabs-quantidade.tsx
    tabs-valor.tsx
    tabs-pagamento.tsx
    tabs-revisao.tsx
  /contract-status-badge.tsx
  /confirmation-view.tsx
/lib
  supabase-client.ts
  calculations.ts                    -> cálculo de valor total
  validations.ts                     -> schemas (ex: zod)
```

## Telas e Fluxos

### 1. Login / Cadastro (Vendedor)
- Formulário simples: nome, telefone, e-mail, senha
- Usar Supabase Auth diretamente do client (`@supabase/ssr` ou client SDK)

### 2. Histórico de Contratos
- Lista em cards (mobile-first) com: nome do comprador, cultura, valor total, status (badge colorido), data
- Filtro por status
- Botão "Novo Contrato" em destaque (CTA primário)

### 3. Formulário de Criação (por abas)
Navegação em abas sequenciais, mas permitindo voltar livremente (não é wizard rígido de mão única):

1. **Comprador**: nome, documento (opcional), contato
2. **Cultura**: select com lista pré-configurada (`crop_types`) + opção "Outra" (abre campo de texto livre)
3. **Quantidade e Unidade**: unidade vem pré-preenchida com o `default_unit` da cultura, mas é **editável livremente**
4. **Valor**: valor por unidade → sistema calcula e exibe valor total em tempo real (nunca input manual do total)
5. **Pagamento e Prazo**: forma de pagamento (select + opção livre), prazo (texto), data de entrega (opcional)
6. **Revisão**: resumo de tudo antes de gerar o link — última chance de editar antes do contrato sair do estado `rascunho`

Ao confirmar na revisão: gera `confirmation_token`, muda status para `aguardando_confirmacao`, exibe o link para o vendedor copiar/compartilhar (o compartilhamento em si — WhatsApp, etc. — é manual, feito pelo próprio vendedor).

### 4. Tela de Confirmação (Comprador) — `/confirmar/[token]`
- **Sem login, sem menu, sem navegação do app** — página isolada, extremamente leve e direta
- Exibe todos os dados do contrato em linguagem simples (não jurídica)
- Dois botões: **"Confirmar"** e **"Isso está errado"**
- Se "Isso está errado": abre campo de texto para descrever o problema, envia e contrato muda para status `divergencia`
- Se "Confirmar": contrato muda para `confirmado`, PDF é gerado, tela mostra confirmação de sucesso + (se aplicável) link de download

### 5. Detalhe do Contrato (Vendedor)
- Mostra status atual, todos os dados, e:
  - Se `aguardando_confirmacao`: botão para reenviar/copiar link, aviso de validade do token
  - Se `confirmado`: botão de download do PDF
  - Se `divergencia`: exibe a observação do comprador, botão "Criar nova versão" (gera novo contrato vinculado ao original via `parent_contract_id`)
  - Se `expirado`: botão "Gerar novo link"

## Componentes shadcn/ui sugeridos
- `Tabs` (navegação do formulário)
- `Form` + `Input` + `Select` (campos)
- `Card` (histórico, revisão)
- `Badge` (status do contrato)
- `Dialog` (confirmação de ações destrutivas, ex: "gerar novo link invalida o anterior")
- `Button` (CTAs primário/secundário bem diferenciados)
- `Skeleton` (loading states)

## Regras de UX Importantes
- Tela do comprador precisa funcionar bem em conexão fraca (3G) — evitar bundles pesados, lazy-load do que não for essencial nessa rota
- Formulário do vendedor: nunca travar navegação entre abas por campo "obrigatório" — só bloquear no botão final de "Gerar contrato"
- Linguagem sempre simples, evitar termos jurídicos crus na interface (o PDF pode ter linguagem mais formal, a interface não)
