# DESIGN-GUIDELINES — Contrato de Safra

Referências visuais: Linear (linear.app), Resend (resend.com), Vercel (vercel.com) — clean, light mode, muito espaço em branco, tipografia forte, cor de destaque usada com moderação.

## Paleta de Cores (sugestão inicial)

| Uso                  | Cor        | Hex        |
|----------------------|------------|------------|
| Fundo principal       | Branco/off-white | `#FFFFFF` / `#FAFAFA` |
| Texto principal       | Cinza-escuro quase preto | `#18181B` |
| Texto secundário      | Cinza médio | `#71717A` |
| Cor de destaque (CTA) | Verde (remete a agro, sem ser clichê "verde folha") | `#16A34A` |
| Cor de destaque hover | Verde mais escuro | `#15803D` |
| Bordas/divisores      | Cinza claro | `#E4E4E7` |
| Status "confirmado"   | Verde | `#16A34A` |
| Status "aguardando"   | Âmbar | `#D97706` |
| Status "divergência"  | Vermelho | `#DC2626` |
| Status "expirado"     | Cinza | `#71717A` |

## Tipografia
- Fonte principal: **Inter** (Google Fonts) — mesma linha visual de Linear/Vercel, ótima legibilidade em telas pequenas
- Fonte alternativa (se quiser diferenciação): **Geist** (usada pela própria Vercel, disponível via `next/font`)
- Hierarquia sugerida:
  - H1: 32-40px, peso 600-700
  - H2: 24-28px, peso 600
  - Corpo: 16px, peso 400
  - Texto secundário/legendas: 14px, peso 400, cor secundária

## Escala de Espaçamento
Base de **4px**:
- 4, 8, 12, 16, 24, 32, 48, 64px
- Padding interno de cards/inputs: 16px
- Espaçamento entre seções da landing: 64-96px

## Border Radius
- Padrão: `8px` (componentes shadcn/ui default `rounded-lg`)
- Cards maiores: `12px`
- Botões: `8px` (consistente com inputs)

## Sombras
- Uso mínimo, só para elevar elementos flutuantes (dropdowns, modais)
- Sombra sutil: `0 1px 3px rgba(0,0,0,0.08)` — nada de sombras pesadas/dramáticas, mantém o visual clean

## Diretrizes de Uso do shadcn/ui

| Componente | Uso no produto |
|------------|----------------|
| `Tabs` | Navegação do formulário de criação de contrato |
| `Form` + `Input` + `Select` + `Textarea` | Todos os campos do formulário |
| `Card` | Histórico de contratos, tela de revisão, tela de confirmação do comprador |
| `Badge` | Indicador de status do contrato (cores da tabela acima) |
| `Button` | Sempre um estilo `default` (sólido) para ação primária, `outline` para secundária, `ghost` para ações terciárias (ex: "cancelar") |
| `Dialog` | Confirmações de ações importantes (ex: reenviar link invalida o anterior) |
| `Skeleton` | Loading states em listas e telas de confirmação |
| `Toast`/`Sonner` | Feedback de ações (contrato criado, link copiado, confirmação recebida) |

## Princípios Gerais
- Light mode único no MVP (sem dark mode por enquanto)
- Sempre priorizar clareza sobre "bonito" — o público-alvo não é necessariamente familiarizado com apps complexos
- Ícones: usar `lucide-react` (já é o padrão que acompanha shadcn/ui), consistente e leve
