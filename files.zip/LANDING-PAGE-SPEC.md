# LANDING-PAGE-SPEC — Contrato de Safra

> Apenas estrutura e diretrizes de layout. Sem copy, headlines ou textos definitivos.

## Seções (em ordem)

### 1. Hero
- **Objetivo**: comunicar em segundos o que é e para quem é
- **Layout**: título grande à esquerda (ou centralizado), CTA primário logo abaixo, ilustração/mockup do formulário por abas à direita (ou abaixo, se mobile)
- **Elementos visuais**: mockup do produto (print da tela de criação de contrato), não usar foto genérica de banco de imagem

### 2. Problema
- **Objetivo**: nomear a dor (venda de safra sem contrato, risco de calote/divergência) de forma que o produtor se reconheça
- **Layout**: bloco de texto curto + ícone ou ilustração simples representando "acordo verbal / incerteza"

### 3. Solução
- **Objetivo**: mostrar como o app resolve, em 3-4 passos simples
- **Layout**: grid de 3 ou 4 colunas (desktop) / stack vertical (mobile), cada coluna com ícone + passo (ex: "Escolha a cultura", "Defina os termos", "Envie o link", "Contrato pronto")

### 4. Como Funciona (detalhamento)
- **Objetivo**: aprofundar o fluxo vendedor → comprador → PDF
- **Layout**: diagrama horizontal simples (linha do tempo) ou screenshots lado a lado mostrando a tela do vendedor e a tela de confirmação do comprador

### 5. Diferencial
- **Objetivo**: reforçar por que isso é diferente de "um contrato genérico da internet" ou de soluções para grandes tradings
- **Layout**: 2-3 blocos lado a lado (ex: "Feito para produtor pequeno", "Sem cadastro pro comprador", "Histórico organizado")

### 6. Social Proof (se houver, na fase de expansão)
- **Objetivo**: gerar confiança regional
- **Layout**: cards simples com nome/região do produtor (sem depoimento inventado — só incluir quando houver usuários reais)
- Nota: como o MVP ainda está em validação com os próprios fundadores, esta seção pode ficar **oculta/comentada** até haver depoimentos reais

### 7. CTA Final
- **Objetivo**: converter para cadastro
- **Layout**: bloco full-width, CTA único e grande, sem distrações ao redor

## Hierarquia de CTAs
- **CTA primário** (repetido no Hero e no final): "Criar minha conta" / equivalente — sempre botão sólido, cor de destaque
- **CTA secundário** (se houver, ex: "Ver como funciona"): botão outline ou link, nunca competindo visualmente com o primário
- Apenas **um CTA primário visível por seção** — evitar poluição de botões

## Diretrizes Gerais de Layout
- Estilo clean, muito espaço em branco, sem elementos decorativos excessivos
- Máximo 2 CTAs distintos na página inteira (criar conta / ver como funciona)
- Mobile-first: toda seção deve ser pensada primeiro em coluna única, depois expandida para grid em desktop
